#!/usr/bin/env python
# ~*~ coding: utf-8 ~*~
#
from __future__ import absolute_import

from django.urls import path
from rest_framework_bulk.routes import BulkRouter
from .. import api


app_name = 'jdos'

router = BulkRouter()

urlpatterns = [
    path('jdos/', api.erp_binding, name='erp-binding'),
    path('jdos/reload/', api.reload_sercret_key, name='reload-key'),
    # url(r'^v2/jdos$', api.erp_binding_ips),
    # url(r'^v1/jdos/reload$', api.reload_sercret_key),
    # url(r'^v1/jdos$', api.erp_binding),
    # url(r'^ad$', api.erp_binding_ad),
    #url(r'^v1/jdos/appname/(?P<appname>[0-20]+)$', views.query),
]

urlpatterns += router.urls
